<?php include "inc/vars.php"; ?>

<!doctype html>
<html lang="ru">
<head>
    <link rel="icon" href="favicon.ico" type="image/x-icon" />
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon" />

    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta charset="UTF-8">
    <title>Cloud Executive Forum</title>
    <meta name="keywords" content="Cloud Executive Forum"/>
    <meta name="description" content="Cloud Executive Forum.Облачные технологии для решения бизнес-задач"/>

    <script src="assets/js/jquery/jquery.min.js"></script>
    <!--
    <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">
-->
    <link rel="stylesheet" href="assets/css/awf/css/font-awesome.min.css"/>
    <link rel="stylesheet" href="assets/js/bootstrap/css/bootstrap.min.css"/>
    <link rel="stylesheet" href="assets/js/bootstrap/css/bootstrap-theme.css"/>
    <script src="assets/js/bootstrap/js/bootstrap.min.js"></script>

    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>

    <![endif]-->
    <script src="assets/js/placeholders.min.js"></script>

    <script src="assets/js/jquery/jquery.form.js"></script>

    <link rel="stylesheet" href="assets/css/style.css"/>
    <script src="assets/js/theme.js"></script>

    <!-- Facebook Pixel Code -->
    <script>
        !function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function()
        {n.callMethod? n.callMethod.apply(n,arguments):n.queue.push(arguments)}
        ;if(!f._fbq)f._fbq=n;
        n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;
        t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,
        document,'script','https://connect.facebook.net/en_US/fbevents.js');
        fbq('init', '1790375757902712');
        fbq('track', 'PageView');
        fbq('track', 'CompleteRegistration');
    </script>
    <noscript><img height="1" width="1" style="display:none"
    src="https://www.facebook.com/tr?id=1790375757902712&ev=PageView&noscript=1"
    /></noscript>
    <!-- DO NOT MODIFY -->
    <!-- End Facebook Pixel Code -->
    
    <!--Google Analytics-->
    <script>
        (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function()
        { (i[r].q=i[r].q||[]).push(arguments)}
        ,i[r].l=1*new Date();a=s.createElement(o),
        m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
        })(window,document,'script','//www.google-analytics.com/analytics.js','ga');
        ga('create', 'UA-86192170-1', 'auto');
        ga('send', 'pageview');
        setTimeout("ga('send', 'event', 'read', '15_seconds')", 15000);
    </script>
</head>
<body id="home">
    <?php include "inc/blocks/menu.php" ?>
    <?php include "inc/blocks/orators.php" ?>
    <?php include "inc/blocks/first-in-ru.php" ?>
    <?php include "inc/blocks/programm.php" ?>
    <?php #include "inc/blocks/reviews.php" ?>   
    <?php include "inc/blocks/registration.php" ?>
    <?php include "inc/blocks/location.php" ?>


    <footer>
        <div class="container">
            <div class="col-md-4 col-sm-4 col-sx-12 text-left">
                <img src="assets/img/logos-footer.png" alt="SalesForce and CT consulting" />
            </div>
            <div class="col-md-4 col-sm-4 col-sx-12">
                <div class="f-socs text-center">
                    <a class="f-fb" target="_blank" href="https://www.facebook.com/crmsalesforce"></a>
                    <a class="f-in" target="_blank" href="https://www.linkedin.com/company/ct-consulting---salesforce-com-reseller?trk=prof-following-company-logo"></a>
                    <a class="f-tw" target="_blank" href="https://twitter.com/Salesforce_Rus"></a>
                    <a class="f-yt" target="_blank" href="http://www.youtube.com/channel/UCqj6MJCSszleDzqIcHgol_Q"></a>
                </div>
            </div>
            <div class="col-md-4 col-sm-4 col-sx-12 text-right contacts">
                +7 (495) 646 11 20<br />
                <a href="mailto:info@ctconsult.ru">info@ctconsult.ru</a>
            </div>
        </div>
    </footer>
    <!-- Yandex.Metrika counter -->
    <script type="text/javascript">
        (function (d, w, c) {
            (w[c] = w[c] || []).push(function() {
                try {
                    w.yaCounter40487935 = new Ya.Metrika({
                        id:40487935,
                        clickmap:true,
                        trackLinks:true,
                        accurateTrackBounce:true,
                        webvisor:true
                    });
                } catch(e) { }
            });

            var n = d.getElementsByTagName("script")[0],
                s = d.createElement("script"),
                f = function () { n.parentNode.insertBefore(s, n); };
            s.type = "text/javascript";
            s.async = true;
            s.src = "https://mc.yandex.ru/metrika/watch.js";

            if (w.opera == "[object Opera]") {
                d.addEventListener("DOMContentLoaded", f, false);
            } else { f(); }
        })(document, window, "yandex_metrika_callbacks");
    </script>
    <noscript><div><img src="https://mc.yandex.ru/watch/40487935" style="position:absolute; left:-9999px;" alt="" /></div></noscript>
    <!-- /Yandex.Metrika counter -->
</body>
</html>