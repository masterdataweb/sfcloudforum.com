 <?php
$orators = array(
    0 => array(
        'desc' => 'Adam Bukkosy',
        'who' => '<span class = "name-orator">Adam Bukkosy</span><br/> Ведущий менеджер по работе с партнерами в странах Центральной и Восточной Европы, Salesforce',
        'img' => 'assets/img/orators2016/Adam-Bukkosy.gif',
    ),
    1 => array(
        'desc' => 'Любовь Малых',
        'who' => '<span class = "name-orator">Любовь Малых</span><br/> Старший менеджер по работе с клиентами, Salesforce',
        'img' => 'assets/img/orators2016/Lyubov-Malykh.gif',
    ),
    2 => array(
        'desc' => 'Антон Куприянов',
        'who' => '<span class = "name-orator">Антон Куприянов</span><br/> Региональный менеджер - Россия и СНГ, Salesforce',
        'img' => 'assets/img/orators2016/Anton-Koupriyanov.gif',
    ),
    3 => array(
        'desc' => 'Дмитрий Васильковский',
        'who' => '<span class = "name-orator">Дмитрий Васильковский</span><br/> Коммерческий директор, CT Consulting',
        'img' => 'assets/img/orators2016/Dmitry-Vasilkovsky-(2).gif',
    ),
    4 => array(
        'desc' => 'Дарья Римская',
        'who' => '<span class = "name-orator">Дарья Римская</span><br/> Руководитель отдела продаж, CT Consulting',
        'img' => 'assets/img/orators2016/Daria.gif',
    ),

    5 => array(
        'desc' => 'Анвер Лайшев',
        'who' => '<span class = "name-orator">Анвер Лайшев</span><br/>  Генеральный директор, Мэконс',
        'img' => 'assets/img/orators2016/Анвер.jpg',
    ),
    6 => array(
        'desc' => 'Леонид Денисов',
        'who' => '<span class = "name-orator">Леонид Денисов</span><br/>   Менеджер стратегических клиентов IoT Сloud, Cisco',
        'img' => 'assets/img/orators2016/ЛеонидДенисов-2.gif',
    ),
    7 => array(
        'desc' => 'Рыдлев Максим',
        'who' => '<span class = "name-orator">Рыдлев Максим</span><br/>  Директор по продажам, Autopiter',
        'img' => 'assets/img/orators2016/maxim2.jpg',
    )
);

$col = true;
?>

<div id="orators">
    <div class="container container-custom">
        <h3 class = "text-center text-center-custom">Спикеры #CEFORUM2016</h3>
        <div class="rel-t">
        <?php foreach ($orators as $ori): ?>
            <div class = "col-md-custom">  <img src="<?php print $ori['img'] ?>"  alt="<?php print $ori['desc'] ?>"/> <div class = "who-orator"><?php print $ori['who'] ?></div></div>
        <?php endforeach; ?>

        </div>
    </div>

</div>  