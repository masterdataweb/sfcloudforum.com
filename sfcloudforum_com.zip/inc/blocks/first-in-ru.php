<div id="first-in-ru" class="block invert">
    <div class="container">

        <h3>Cloud Executive Forum<br /></h3>

        <p>
            Среди участников <strong>Cloud Executive Forum</strong> - руководители компаний, предприниматели, представители топ-менеджмента, заинтересованные в оптимизации продаж, совершенствовании клиентского сервиса, а также внедрении технологий и инноваций в свой бизнес.
        </p>

        <h2 class="pt40 pb22 pt20">Участники Cloud Executive Forum:</h2>

        <div class="wrap-icons">
            <div class="col-xs-6 col-sm-3 text-center">
                <i class="fa fa-2x fa-briefcase"></i>

                <p style="padding: 0 6px">владельцы компаний</p>
            </div>
            <div class="col-xs-6 col-sm-3 text-center">
                <i class="fa fa-2x fa-users"></i>

                <p>руководители отделов&nbsp;IT</p>

            </div>
            <div class="col-xs-6 col-sm-3 text-center">
                <i class="fa fa-2x fa-line-chart"></i>

                <p>директора по информационной безопасности</p>
            </div>
            <div class="col-xs-6 col-sm-3 text-center">
                <i class="fa fa-2x fa-cogs"></i>

                <p>технические директора</p>
            </div>
        </div>
    </div>
</div>