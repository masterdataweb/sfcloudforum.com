<div id="partners">
    <h4 style="text-align: center;">Наши партнёры:</h4>
 <div class="container tac">
       <!-- <div class="col-xs-1-5 col-md-1-5">
            <img src="/assets/img/partners/part1.png" alt="CloudyNews"/>
        </div>
        <div class="col-xs-1-5 col-md-1-5">
            <img src="/assets/img/partners/part2.png" alt="MSKIT.ru"/>
        </div>
        <div class="col-xs-1-5 col-md-1-5">
            <img src="/assets/img/partners/part3.png" alt="ComNews"/>
        </div>-->
        <div class = "partners-custom">
            <div>
                <a href = "http://www.crm-practice.ru/"><img src="/assets/img/partners/part4.png" alt="ПрактикаCRM"/></a>
            </div>
            <div>
                <a href = "https://bizfam.ru/"><img src="/assets/img/partners/part6.png" alt="Business Family"/></a>
            </div>
            <div>
                <a href = "http://www.crn.ru/"><img src="/assets/img/partners/part9.gif" alt="CRN"/></a>
            </div>
            <div>
                <a href = "http://www.pcweek.ru/"><img src="/assets/img/partners/part10.gif" alt="PCWEEK"/></a>
            </div>
            <div>
                <a href = "http://cloudjournal.ru/"><img src="/assets/img/partners/part8.gif" alt="В облаке.рф"/></a>
            </div>
        </div>
    </div>
</div> 