<div id="header">
    <div class="container">
        <div class="col-xs-6">
            <div id="logos">
                <img class="logo" src="assets/img/logos.png" alt="SalesForce and CT consulting"/>
            </div>
        </div>
        <div class="col-xs-6 text-right">
            <div class="h-soc hidden-xs">
                <a class="fb" target="_blank" href="https://www.facebook.com/crmsalesforce"></a>
                <a class="in" target="_blank"
                   href="https://www.linkedin.com/company/ct-consulting---salesforce-com-reseller?trk=prof-following-company-logo"></a>
                <a class="tw" target="_blank" href="https://twitter.com/Salesforce_Rus"></a>
                <a class="yt" target="_blank" href="http://www.youtube.com/channel/UCqj6MJCSszleDzqIcHgol_Q"></a>
                <!--                 <div class="language-list-wr">
                                    <a class="language-btn" href="javascript:;">RU</a>
                                    <ul class="language-list-dropdown">
                                        <li class="language-list-item"><a href="/" class="language-list-item-link">RU</a></li>
                                        <li class="language-list-item"><a href="/en" class="language-list-item-link">EN</a></li>
                                    </ul>
                                </div> -->
            </div>


            <a href="#" class="menu-btn"></a>

            <div class="h-info hidden-xs">
                +7 (495) 646 11 20<br/>
                <a href="mailto:info@ctconsult.ru">info@ctconsult.ru</a>
            </div>
        </div>
    </div>
</div>

<div id="main-front">
    <div class="fullscreen background" style="background-image:url('assets/img/front.jpg');">
        <div class="content-a">
            <div class="content-b">
                <h1>
                    <strong>Cloud Executive Forum</strong> <br/ ><strong>Облачные технологии <br/ >для решения
                        бизнес-задач</strong>
                </h1>
                <h2>
                    <strong> Специальный участник: </strong><a href="http://www.cisco.com/c/ru_ru/index.html"><img class="cisco-img" src="assets/img/cisco.png" style="width: 100px; height: 50px;"></a>
                </h2>
            </div>
        </div>
        <div id="mf-bottom">
            <div class="desc">
                8 НОЯБРЯ ​​2016 г.| МОСКВА <span class="hidden-xxs">|</span>

                <a href="https://www.google.com.ua/maps/place/Courtyard+Moscow+City+Center/@55.758002,37.6018483,17z/data=!3m1!4b1!4m5!3m4!1s0x46b54a4f3912abfb:0x5da7ca9dc08e69b9!8m2!3d55.758002!4d37.604037"><i
                        class="fa fa-map-marker"></i>&nbsp;г. Москва, Вознесенский переулок, 7,
                    Отель Кортъярд Марриотт Москва Центр</a>

            </div>
            <!-- a class="toForm btn btn-primary" href="#reg">Зарегистрироваться</a-->

            <div style="clear: both;"></div>
        </div>
    </div>
</div>

<div id="main-menu" style="display: none;">
    <div class="container">
        <div class="wrap-close">
            <a href="#close" class="btn-menu-close"></a>
        </div>
    </div>
    <div class="wrap-menu">
        <a href="#main-front">Главная</a>
        <a href="#orators">Участники</a>
        <a href="#programm">Программа</a>
        <!--a href="#reg">Регистрация</a-->
    </div>
    <div class="wrap-menu-bottom">
        <div class="f-socs text-center">
            <a class="f-fb" target="_blank" href="https://www.facebook.com/crmsalesforce"></a>
            <a class="f-in" target="_blank"
               href="https://www.linkedin.com/company/ct-consulting---salesforce-com-reseller?trk=prof-following-company-logo"></a>
            <a class="f-tw" target="_blank" href="https://twitter.com/Salesforce_Rus"></a>
            <a class="f-yt" target="_blank" href="http://www.youtube.com/channel/UCqj6MJCSszleDzqIcHgol_Q"></a>
        </div>
        <div class="menu-contacts text-center">
            +7 (495) 646 11 20<br/>
            <a href="mailto:info@customertimes.com">info@customertimes.com</a>
        </div>
    </div>
</div>

<div id="front-down" class="block invert tac">
    <div class="container">
        <div class="row">
            <div class="text">
                <p>
                    Уже 3-й раз в Москве! Cloud Executive Forum-III — мероприятие для тех, кто хочет с максимальной
                    выгодой использовать новейшие облачные технологии для бизнеса. Время конкуренции товаров и услуг
                    прошло. Настало время конкуренции моделей управления бизнесом. На нашем мероприятии вы познакомитесь
                    с самым инновационным и действенным в мире инструментом для построения лучших моделей управления
                    продажами, сервисом, маркетингом. Если вы хотите в современных, крайне динамичных условиях, быть в
                    лидерах – используйте решения от лидеров.
            </div>
        </div>
        <!--div class="row">
            <a class="toForm btn btn-primary" href="#reg">Зарегистрироваться</a>
        </div-->
        <div style="clear: both;"></div>

    </div>
</div>