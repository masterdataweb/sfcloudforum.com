<div id="location">
    <h4 style="text-align: center;">Место проведения:</h4>
    <div class="container">

        <div class=" col-md-7 col-lg-7" id="hotel">
            <img src="/assets/img/hotel.jpg"  style ="width: 100%" alt="">
        </div>
        <div class="  col-md-5 col-lg-5">
            <script type="text/javascript" charset="utf-8" async src="https://api-maps.yandex.ru/services/constructor/1.0/js/?sid=cf7BMFrdYWNVuVLPyT37EoAFDugEW97O&amp;width=475&amp;height=394&amp;lang=ru_RU&amp;sourceType=constructor&amp;scroll=true"></script>
        </div>
    </div>
    <p style="text-align: center;">Вознесенский переулок, 7, Москва, 125009, Россия</p>
</div>