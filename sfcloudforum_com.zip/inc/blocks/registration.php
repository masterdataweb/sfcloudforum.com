<div id="reg" class="block invert">
    <div class="container">
        <div id="fb-form-wrap">
             <!--<div class="text">
                Регистрация открыта! Количество мест ограничено.<br/>
                Участие бесплатное - вход по предварительной регистрации.<br/>
                Для того, чтобы подать заявку на участие, заполните форму:
            </div> -->
            <div style = "margin-top: 10px; text-align: center">
              Регистрация более недоступна
            </div>

         <div class="rowb">
<!--
                <form class="fb-form" action="https://www.salesforce.com/servlet/servlet.WebToLead?encoding=UTF-8"  method="POST" onsubmit="ga('send', 'event', 'form', 'send');">
                    <input type=hidden name="oid" value="00D200000008P1X">
                    <input type=hidden name="retURL" value="www.cloudexecutiveforum.ru">
                    <input type="hidden" name="LeadSourсe" value="Маркетинговые кампании">
					<input type="hidden" name="Category__c" value="потенциальный клиент">
					<input type="hidden" name="Status" value="Получена регистрация">
                    <div class="form-group">
                        <div class="col-md-4 col-sm-4">
                            <input type="text" class="form-control" id="first_name" placeholder="Имя" name="first_name">
                        </div>
                        <div class="col-md-4 col-sm-4">
                            <input type="text" class="form-control" id="last_name" placeholder="Фамилия" name="last_name">
                        </div>
                        <div class="col-md-4 col-sm-4">
                            <input type="text" class="form-control" id="dolzhnost" placeholder="Должность" name="title">
                        </div>
                    </div>

                    <div class="form-group">
                        <div class="col-md-4 col-sm-4">
                            <input type="text" class="form-control" id="company" placeholder="Компания" name="company">
                        </div>
                        <div class="col-md-4 col-sm-4">
                            <input type="tel" class="form-control" id="phone" placeholder="Телефон" name="mobile">
                        </div>
                        <div class="col-md-4 col-sm-4">
                            <input type="email" class="form-control" id="email" placeholder="Email" name="email">
                        </div>
                    </div>
                   <div class="form-group" >
                       
                        <div class="col-md-4 col-sm-4" >
                            
                               
               
                                <select  style=" font-size: 14px; " class="form-control" id="00N20000001eQmU" name="00N20000001eQmU" title="Размер компании">
                                    <option style =  "display: none;"  value="" disabled selected>Количество сотрудников</option>
                                    <option value="1-30 сотрудников">1-30 сотрудников</option>
                                    <option value="30-100 сотрудников">30-100 сотрудников</option>
                                    <option value="100-500 сотрудников">100-500 сотрудников</option>
                                    <option value="500-3000 сотрудников">500-3000 сотрудников</option>
                                    <option value="3000+сотрудников">3000+сотрудников</option>
                                </select>
                           

                        </div>
                         <div class="col-md-4 col-sm-4" >
                            <select style=" font-size: 14px; " class="form-control" id="00N20000002N2X5" name="00N20000002N2X5" title="Используете ли вы Salesforce?">
                                <option style =  "display: none;"  value="" disabled selected>Используете ли вы Salesforce?</option>
                                <option value="Да">Да</option>
                                <option value="Нет">Нет</option>
                            </select>
                        </div>
                        
                    </div>
                    <input name="Campaign_ID" type="hidden" value="701D0000001ahqH"/>

                    <div class="form-group">
                        <div class="col-md-4 col-md-offset-4 col-sm-12 ">
                            <input class="fb-submit btn btn-primary btn-block" type="submit" name="submit"  onclick="yaCounter40487935.reachGoal('registration'); ga('send', 'event', 'registration', 'click');" value="Зарегистрироваться">
                        </div>
                    </div>
                </form>
-->
            </div> 
        </div>
        <div id="fb-sec-wrap" class="text-center" style="display: none">
            Спасибо! Ваша заявка на участие отправлена.<br/> В ближайшее время с Вами свяжется наш специалист для
            подтверждения регистрации.
        </div>
    </div>
</div>