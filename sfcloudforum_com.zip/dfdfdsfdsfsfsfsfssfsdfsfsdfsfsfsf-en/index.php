<?php include "inc/vars.php"; ?>

<!doctype html>
<html lang="ru">
<head>
    <link rel="icon" href="/favicon.ico" type="image/x-icon" />
    <link rel="shortcut icon" href="/favicon.ico" type="image/x-icon" />

    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta charset="UTF-8">
    <meta name="author" content="asapp.eu">
    <title>Cloud Executive Forum</title>
    <meta name="keywords" content="Cloud Executive Forum"/>
    <meta name="description" content="Cloud Executive Forum"/>

    <script src="assets/js/jquery/jquery.min.js"></script>
    <!--
    <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">
-->
    <link rel="stylesheet" href="assets/css/awf/css/font-awesome.min.css"/>
    <link rel="stylesheet" href="assets/js/bootstrap/css/bootstrap.min.css"/>
    <link rel="stylesheet" href="assets/js/bootstrap/css/bootstrap-theme.css"/>
    <script src="assets/js/bootstrap/js/bootstrap.min.js"></script>

    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>

    <![endif]-->
    <script src="assets/js/placeholders.min.js"></script>

    <script src="assets/js/jquery/jquery.form.js"></script>

    <link rel="stylesheet" href="assets/css/style.css"/>
    <script src="assets/js/theme.js"></script>
</head>
<body id="home">
    <?php include "inc/blocks/menu.php" ?>
    <?php include "inc/blocks/orators.php" ?>
    <?php include "inc/blocks/first-in-ru.php" ?>
    <?php include "inc/blocks/programm.php" ?>
    <?php #include "inc/blocks/reviews.php" ?>
    <?php include "inc/blocks/partners.php" ?>
    <?php include "inc/blocks/registration.php" ?>


    <footer>
        <div class="container">
            <div class="col-md-4 col-sm-4 col-sx-12 text-left">
                <img src="assets/img/logos-footer.png" alt="SalesForce and CT consulting" />
            </div>
            <div class="col-md-4 col-sm-4 col-sx-12">
                <div class="f-socs text-center">
                    <a class="f-fb" target="_blank" href="https://www.facebook.com/crmsalesforce"></a>
                    <a class="f-in" target="_blank" href="https://www.linkedin.com/company/ct-consulting---salesforce-com-reseller?trk=prof-following-company-logo"></a>
                    <a class="f-tw" target="_blank" href="https://twitter.com/Salesforce_Rus"></a>
                    <a class="f-yt" target="_blank" href="http://www.youtube.com/channel/UCqj6MJCSszleDzqIcHgol_Q"></a>
                </div>
            </div>
            <div class="col-md-4 col-sm-4 col-sx-12 text-right contacts">
                +7 (495) 646 11 20<br />
                <a href="mailto:info@ctconsult.ru">info@consult.ru</a>
            </div>
        </div>
    </footer>
</body>
</html>