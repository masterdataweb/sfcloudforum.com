<?php
$programm = array(
    '09:30 - 10:00' => 'Registration of participants. Welcome coffee&tea',
    '10:00 - 10:15' => 'Welcome remarks by Dmitry Vasilkovsky, Head of sales at CT Consulting',
    '10:15 – 10:35' => '<b>The 21st century is the century for understanding customer service.</b> <br>Hrvoje Supic Sales Director, Eastern Europe, Russia/CIS at Salesforce.com</br>',
    '11:00 – 12:00' => '<b>Marketing & Sales Together at Last – Learn how traction is bringing together sales and marketing using top platforms like Pardot and Sales Cloud.</b> <br>Anton Kouprianov, Country Manager,Russia & CIS at Salesforce.com<br>Tamta Gamezardashvili, Marketing Automation Specialist at Salesforce.com </br>',
    '12:00 - 12:15' => 'Customer Success Story',
    '12:15 - 12:30' => 'Coffee-break',
    '12:30 - 13:15' => '<b>Service Cloud/Communities/Social Engage</b>. <br>Liubov Malykh Snr. Account Executive - Russia and CIS, Salesforce.com </br>',
    '13:15 - 13:30' => 'Customer Success Story',
    '13:30 - 14:10' => 'Lunch/Networking',
    '14:10 - 14:40' => '<b>Transform your business for growth</b>.<br> Hrvoje Supic, Sales Director, Eastern Europe, Russia/CIS at Salesforce.com</br>',
    '14:40 - 15:10' => '<b>Analytics&Reporting: Innovative Business Intelligence</b>.<br> Evgeniy Chuvirov, Head of BI dept. SAP BI/BOBJ/ETL/DQM expert in Masterdata</br>',
    '15:10 – 15:40' => '<b>CT Mobile - new interactive solution</b>.<br> Daria Rimskaya,Head of Sales at CT Consulting</br>',
    '15:40 - 16:10' => 'Question&Answer Session',
    '16:10 - 16:40' => 'Experience the Future of CRM Today: Welcome to the new Salesforce Tools',
    '16:40 - 17:00' => 'Question&Answer Session',
    '17:00' => 'Cocktails & Farewell Drinks'
);
?>

<div id="programm" class="invert">
    <div class="container container-custom">
        <h3 class="text-center text-center-custom">Programme #CEFORUM2016</h3>
        <div class="row1">
            <div class="col-xs-3 col-lg-2">
            </div>
            <div class="col-xs-9 col-lg-10">
                <div class="rp-line">
                    <div class="block-margin66"></div>
                </div>
            </div>
        </div>

        <?php foreach ($programm as $time => $text) : ?>
            <div class="row1">
                <div class="col-xs-3 col-lg-2 pr-time-wrap">
                    <div class="rp-time">
                        <?php print $time ?>
                    </div>
                </div>
                <div class="col-xs-9 col-lg-10">
                    <div class="rp-line">
                        <div class="rp-point">
                            <div class="pr-text">
                                <?php print $text ?>
                                <div class="pr-d-line"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>

        <div class="row1">
            <div class="col-xs-3 col-lg-2">
            </div>
            <div class="col-xs-9 col-lg-10">
                <div class="rp-line">
                    <div class="block-margin66"></div>
                </div>
            </div>
        </div>
    </div>
</div>