<div id="header">
    <div class="container">
        <div class="col-xs-6">
            <div id="logos">
                <img class="logo" src="assets/img/logos.png" alt="SalesForce and CT consulting"/>
            </div>
        </div>
        <div class="col-xs-6 text-right">
            <div class="h-soc hidden-xs">
                <a class="fb" target="_blank" href="https://www.facebook.com/crmsalesforce"></a>
                <a class="in" target="_blank" href="https://www.linkedin.com/company/ct-consulting---salesforce-com-reseller?trk=prof-following-company-logo"></a>
                <a class="tw" target="_blank" href="https://twitter.com/Salesforce_Rus"></a>
                <a class="yt" target="_blank" href="http://www.youtube.com/channel/UCqj6MJCSszleDzqIcHgol_Q"></a>
                <div class="language-list-wr">
                    <a class="language-btn" href="javascript:;">EN</a>
                    <ul class="language-list-dropdown">
                        <li class="language-list-item"><a href="/" class="language-list-item-link">RU</a></li>
                        <li class="language-list-item"><a href="/en" class="language-list-item-link">EN</a></li>
                    </ul>
                </div>
            </div>


            <a href="#" class="menu-btn"></a>

            <div class="h-info hidden-xs">
                +7 (495) 646 11 20<br/>
                <a href="mailto:info@ctconsult.ru">info@consult.ru</a>
            </div>
        </div>
    </div>
</div>

<div id="main-front">
    <div class="fullscreen background" style="background-image:url('assets/img/front-bg.gif');">
        <div class="content-a">
            <div class="content-b">
                <h1>
                   Cloud Executive Forum<br/>
                   Cloud computing technologies:<br/> perspectives and challenges of business
                </h1>
            </div>
        </div>
        <div id="mf-bottom">
            <div class="desc">
                July 7, 2016   | Moscow <span class="hidden-xxs">|</span>

                <a href="http://www.swissotel-hotels.ru/hotels/moscow/map-directions/" target="_blank" title="Look at map">
                    <i class="fa fa-map-marker"></i>Swissotel Krasnye Holmy Moscow Hotel
</a> (Kosmodamianskaya nab., 52 bld. 6 ▪ 115054 Moscow ▪ Russia)​

            </div>
            <!--a class="toForm btn btn-primary" href="#reg">Register</a-->

            <div style="clear: both;"></div>
        </div>
    </div>
</div>

<div id="main-menu" style="display: none;">
    <div class="container">
        <div class="wrap-close">
            <a href="#close" class="btn-menu-close"></a>
        </div>
    </div>
    <div class="wrap-menu">
        <a href="#main-front">Home</a>
        <a href="#orators">Speakers</a>
        <a href="#programm">Program</a>
        <!--a href="#reg">Register</a-->
    </div>
    <div class="wrap-menu-bottom">
        <div class="f-socs text-center">
            <a class="f-fb" target="_blank" href="https://www.facebook.com/crmsalesforce"></a>
            <a class="f-in" target="_blank" href="https://www.linkedin.com/company/ct-consulting---salesforce-com-reseller?trk=prof-following-company-logo"></a>
            <a class="f-tw" target="_blank" href="https://twitter.com/Salesforce_Rus"></a>
            <a class="f-yt" target="_blank" href="http://www.youtube.com/channel/UCqj6MJCSszleDzqIcHgol_Q"></a>
        </div>
        <div class="menu-contacts text-center">
            +7 (495) 646 11 20<br/>
            <a href="mailto:info@ctconsult.ru">info@ctconsult.ru</a>
        </div>
    </div>
</div>

<div id="front-down" class="block invert tac">
    <div class="container">
        <div class="row">
            <div class="text">
                Back in Moscow! Cloud Executive Forum - an event for those who want to capitalize on the latest cloud technologies for business. Time competition of goods and services has passed. It is time for the competition of business management models. At this event you will learn about the most innovative tool in the world to build the best sales management models , services and marketing. If you want to be in the lead of modern , highly dynamic environment , use solutions from the leaders.
            </div>
        </div>
        <!--div class="row">
            <a class="toForm btn btn-primary" href="#reg">Register</a>
        </div-->
        <div style="clear: both;"></div>

    </div>
</div>