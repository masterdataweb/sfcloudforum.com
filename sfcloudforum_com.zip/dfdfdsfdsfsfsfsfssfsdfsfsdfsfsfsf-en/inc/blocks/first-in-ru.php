<div id="first-in-ru" class="block invert">
    <div class="container">

        <h3></h3>

        <p>
            Registered participants include CEOs , entrepreneurs, representatives of top management who are interested in optimizing sales , improving customer service , as well  as increasing the efficiency customer relationships for companies of all sizes and innovation in the business.
        </p>

        <h2 class="pt40 pb22 pt20">Attendees:</h2>

        <div class="wrap-icons">
            <div class="col-xs-6 col-sm-3 text-center">
                <i class="fa fa-2x fa-briefcase"></i>

                <p style="padding: 0 6px">Business owners</p>
            </div>
            <div class="col-xs-6 col-sm-3 text-center">
                <i class="fa fa-2x fa-users"></i>

                <p>Head of IT departments</p>

            </div>
            <div class="col-xs-6 col-sm-3 text-center">
                <i class="fa fa-2x fa-line-chart"></i>

                <p>Heads of information security</p>
            </div>
            <div class="col-xs-6 col-sm-3 text-center">
                <i class="fa fa-2x fa-cogs"></i>

                <p>Technology executives</p>
            </div>
        </div>
    </div>
</div>