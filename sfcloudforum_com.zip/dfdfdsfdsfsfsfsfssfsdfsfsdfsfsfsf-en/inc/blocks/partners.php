 <!--<div id="partners">
 <div class="container tac">
        <div class="col-xs-6 col-md-3">
            <img src="/assets/img/partners/part1.png" alt="CloudyNews"/>
        </div>
        <div class="col-xs-6 col-md-3">
            <img src="/assets/img/partners/part2.png" alt="MSKIT.ru"/>
        </div>
        <div class="col-xs-6 col-md-3">
            <img src="/assets/img/partners/part3.png" alt="ComNews"/>
        </div>
        <div class="col-xs-6 col-md-3">
            <img src="/assets/img/partners/part4.png" alt="ПрактикаCRM"/>
        </div>
    </div>
</div>-->