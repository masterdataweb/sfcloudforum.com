<div id="reviews">
    <div class="container">
        <div class="desc">
        В этом году впервые побывала на SALESforce.<br />
        Впечатления в целом хорошие, ребята большие молодцы, что организовали такую масштабную конференцию, на которую съезжаются люди со всего мира.
        </div>
        <div class="hwo">
            David Martinelli, Digital Marketing Manager,<br />
            McDonald's Corporation
        </div>
    </div>
</div>