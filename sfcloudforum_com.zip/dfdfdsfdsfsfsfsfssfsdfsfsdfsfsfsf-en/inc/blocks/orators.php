 <?php
$orators = array(
    0 => array(
        'desc' => 'Adam Bukkosy',
        'who' => '<span class = "name-orator">Adam Bukkosy</span><br/> Alliances Manager, CEE, Turkey, Russia/CIS, Salesforce.com',
        'img' => 'assets/img/orators2016/Adam-Bukkosy.gif',
    ),
    1 => array(
        'desc' => 'Hrvoje Supic',
        'who' => '<span class = "name-orator">Hrvoje Supic</span><br/> Sales Director, Eastern Europe, Russia/CIS, Salesforce. com',
        'img' => 'assets/img/orators2016/Hrvoje-Supić.gif',
    ),
    2 => array(
        'desc' => 'Lyubov Malykh',
        'who' => '<span class = "name-orator">Lyubov Malykh</span><br/>Snr. Account Executive - Russia and CIS, Salesforce ',
        'img' => 'assets/img/orators2016/Lyubov-Malykh.gif',
    ),
    3 => array(
        'desc' => 'Anton Kouprianov',
        'who' => '<span class = "name-orator">Anton Kouprianov</span><br/> Country Manager - Russia & CIS, Salesforce. com',
        'img' => 'assets/img/orators2016/Anton-Koupriyanov.gif',
    ),

    4 => array(
        'desc' => 'Dmitry Vasilkovsky',
        'who' => '<span class = "name-orator">Dmitry Vasilkovsky</span><br/> Head of Sales, CT Consulting',
        'img' => 'assets/img/orators2016/Dmitry-Vasilkovsky-(2).gif',
    ),
    5 => array(
        'desc' => 'Tamta Gamezardashvili',
        'who' => '<span class = "name-orator">Tamta Gamezardashvili</span><br/> Marketing Automation Specialist, Salesforce. com',
        'img' =>  'assets/img/orators2016/no-ava.gif',
    ),
    6 => array(
        'desc' => 'Evgeniy Chuvirov',
        'who' => '<span class = "name-orator">Evgeniy Chuvirov</span><br/> Head of BI department, Masterdata',
        'img' => 'assets/img/orators2016/ECH.gif',
    ),
    7 => array(
        'desc' => 'Eugene Rudaev',
        'who' => '<span class = "name-orator">Eugene Rudaev</span><br/> Executive Vice President, CT Consulting',
        'img' => 'assets/img/orators2016/Evgeniy-Rudaev.gif',
    ),

    8 => array(
        'desc' => 'Daria Rimskaya',
        'who' => '<span class = "name-orator">Daria Rimskaya</span><br/> Account Executive, CT Consulting',
        'img' =>'assets/img/orators2016/Daria.gif',
    ),
    9 => array(
        'desc' => 'Anton Kupriyanov',
        'who' => '<span class = "name-orator">Anton Kupriyanov</span><br/> Account Executive - Russia and CIS, Salesforce. com',
        'img' => 'assets/img/orators2016/no-ava.gif'
    )
);

$col = true;
?>

<div id="orators">
    <div class="container container-custom">
        <h3 class = "text-center text-center-custom">Speakers #CEFORUM2016</h3>
        <?php foreach ($orators as $ori): ?>
            <div class = "col-md-custom">  <img src="<?php print $ori['img'] ?>"  alt="<?php print $ori['desc'] ?>"/> <div class = "who-orator"><?php print $ori['who'] ?></div></div>
             
        <?php endforeach; ?>

    </div>

</div>  