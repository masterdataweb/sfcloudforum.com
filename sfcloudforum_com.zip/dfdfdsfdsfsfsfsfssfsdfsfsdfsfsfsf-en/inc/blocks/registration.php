<div id="reg" class="block invert">
    <div class="container">
        <div id="fb-form-wrap">
            <div class="text">
              Registration is open! Due to the limited number of participants, <br/>we must insist on demanding an online registration.<br/> Thank you all for your interest in participating.
            </div>

            <div class="rowb">

                <form class="fb-form" action="https://www.salesforce.com/servlet/servlet.WebToLead?encoding=UTF-8"  method="POST">
                    <input type=hidden name="oid" value="00D200000008P1X">
                    <input type=hidden name="retURL" value="www.cloudexecutiveforum.ru">
                     <input type="hidden" name="LeadSourсe" value="Маркетинговые кампании">
					<input type="hidden" name="Category__c" value="потенциальный клиент">
					<input type="hidden" name="Status" value="Получена регистрация">
                    <div class="form-group">
                        <div class="col-md-4 col-sm-4">
                            <input type="text" class="form-control" id="first_name" placeholder="First Name" name="first_name">
                        </div>
                        <div class="col-md-4 col-sm-4">
                            <input type="text" class="form-control" id="last_name" placeholder="Last Name" name="last_name">
                        </div>
                        <div class="col-md-4 col-sm-4">
                            <input type="text" class="form-control" id="dolzhnost" placeholder="Position" name="title">
                        </div>
                    </div>

                    <div class="form-group">
                        <div class="col-md-4 col-sm-4">
                            <input type="text" class="form-control" id="company" placeholder="Company" name="company">
                        </div>
                        <div class="col-md-4 col-sm-4">
                            <input type="text" class="form-control" id="phone" placeholder="Phone" name="mobile">
                        </div>
                        <div class="col-md-4 col-sm-4">
                            <input type="text" class="form-control" id="email" placeholder="Email" name="email">
                        </div>
                    </div>

                    <input name="Campaign_ID" type="hidden" value="701D0000001ah2z"/>

                    <div class="form-group">
                        <div class="col-md-4 col-md-offset-4 col-sm-12 ">
                            <input class="fb-submit btn btn-primary btn-block" type="submit" name="submit" value="Submit">
                        </div>
                    </div>
                </form>

            </div>
        </div>
        <div id="fb-sec-wrap" class="text-center" style="display: none">
            Thank you for registering the conference.<br/> Our manager will contact you soon
        </div>
    </div>
</div>