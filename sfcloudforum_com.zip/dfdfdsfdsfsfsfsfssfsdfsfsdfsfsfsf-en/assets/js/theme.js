$(document).ready(function () {
    var JSAPP = window.JSAPP || {};

    JSAPP.onScroll = function () {
        var sTop = $(document).scrollTop();
        if (sTop > 90) {
            $('body').addClass('scrolled');
        } else {
            $('body').removeClass('scrolled');
        }
    };

    JSAPP.mainMenuInit = function () {
        $('.menu-btn').click(function () {
            $('body').addClass('menu-opened');
            $('#main-menu').fadeIn();
            return false;
        });
        $('.btn-menu-close').click(function () {
            $('body').removeClass('menu-opened');
            $('#main-menu').fadeOut();
            return false;
        });

        $('#main-menu .wrap-menu a, .toForm').click(function () {
            var anchor = $(this);
            var ww = $(window).width();
            var dy = 90;
            if (ww < 768) dy = 66;
            $('body').removeClass('menu-opened');
            $('#main-menu').fadeOut(200);


            $('html, body').stop().animate({
                scrollTop: $(anchor.attr('href')).offset().top - dy
            }, 1000);

            return false;
        });
    };

    JSAPP.orderForm = function () {
        $('.fb-form').ajaxForm({
            crossDomain : true,
            dataType: 'jsonp',
            beforeSubmit: function (formData, jqForm, options) {
                var form = jqForm[0];
                var err = false;
                $(form).find('.error').removeClass('error');
                if (!form.first_name.value || form.first_name.value == $('#first_name').attr('placeholder')) {
                    $(form.first_name).addClass('error');
                    err = true;
                }
                if (!form.last_name.value || form.last_name.value == $('#last_name').attr('placeholder')) {
                    $(form.last_name).addClass('error');
                    err = true;
                }
                if (!form.title.value || form.title.value == $('#dolzhnost').attr('placeholder')) {
                    $(form.title).addClass('error');
                    err = true;
                }
                if (!form.company.value || form.company.value == $('#company').attr('placeholder')) {
                    $(form.company).addClass('error');
                    err = true;
                }
                if (!form.mobile.value || form.mobile.value == $('#phone').attr('placeholder')) {
                    $(form.mobile).addClass('error');
                    err = true;
                }
                if (!form.email.value || form.email.value == $('#email').attr('placeholder')) {
                    $(form.email).addClass('error');
                    err = true;
                } else {
                    if (!validateEmail(form.email.value)) {
                        $(form.email).addClass('error');
                        err = true;
                    }
                }

                if (err) {
                    return false;
                }
            },
            success: function () {
                $('#fb-form-wrap').fadeOut();
                $('#fb-sec-wrap').fadeIn();
                $('html, body').stop().animate({
                    scrollTop: $('#fb-sec-wrap').offset().top - 300
                }, 1000);
            },
            error: function (e) {
                if (e.status == 200) {
                    $('#fb-form-wrap').fadeOut();
                    $('#fb-sec-wrap').fadeIn();
                    $('html, body').stop().animate({
                        scrollTop: $('#fb-sec-wrap').offset().top - 300
                    }, 1000);

                } else {
                    //console.log(e);
                    //console.log('error');
                }
            }
        });
        $('.fb-form input').change(function () {
            $(this).removeClass('error');
        });
    };

    JSAPP.mainMenuInit();
    JSAPP.orderForm();

    $(window).on('scroll', function () {
        JSAPP.onScroll();
    });

    $(window).resize(backgroundResize);
    $(window).focus(backgroundResize);
    backgroundResize();

});

/* resize background images */
function backgroundResize() {
    var windowH = $(window).height();
    $(".background").css({height: windowH + 'px'});
}

function validateEmail(emailaddress) {
    /*
    var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
    if (emailReg.test(emailaddress)) {
        return true;
    }
    return false;
    */
    var regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
    return regex.test(emailaddress);
}

$(document).ready(function () {
    $(".language-btn").click(function(){
        $(".language-list-dropdown").toggleClass("active");
    })
});